const express = require("express");
const rateLimit = require("express-rate-limit");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json({ limit: "20kb" }));
app.use(express.static(path.join(__dirname)));

const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 20,
  standardHeaders: "draft-7",
  legacyHeaders: false,
  message: { error: "Too many requests. Please try again later." }
});

app.use("/api/", apiLimiter);

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, aiConfigured: Boolean(process.env.OPENAI_API_KEY) });
});

app.post("/api/chat", async (req, res) => {
  try {
    const message = String(req.body?.message || "").trim();
    const language = String(req.body?.language || "en").slice(0, 30);

    if (!message) return res.status(400).json({ error: "Please enter a question." });
    if (message.length > 4000) return res.status(400).json({ error: "Please keep your question under 4,000 characters." });
    if (!process.env.OPENAI_API_KEY) {
      return res.status(503).json({ error: "AI is not configured yet. Add OPENAI_API_KEY in your hosting Secrets." });
    }

    const instructions = `You are Smart Media Awareness Hub, a careful digital-media and cyber-safety helper. Reply in the user's requested language (${language}; use Hindi/Hinglish if requested). Give concise, practical educational guidance about checking information, media literacy, privacy, scams, and safe online habits. Never ask for passwords, OTPs, recovery codes, or private information. Do not claim that a news claim is verified unless reliable evidence was actually checked. If asked whether a specific claim is true, explain how to verify it and be clear about uncertainty.`;

    const apiResponse = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${process.env.OPENAI_API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: process.env.OPENAI_MODEL || "gpt-4o-mini",
        instructions,
        input: message,
        max_output_tokens: 500
      })
    });

    const data = await apiResponse.json().catch(() => ({}));
    if (!apiResponse.ok) {
      console.error("OpenAI API error:", apiResponse.status, data?.error?.code || data?.error?.type || "unknown");
      return res.status(502).json({ error: "The AI service could not answer. Check your API key, model access, and API billing." });
    }

    const reply = data.output_text || (data.output || [])
      .flatMap(item => item.content || [])
      .filter(item => item.type === "output_text")
      .map(item => item.text)
      .join("\n");

    if (!reply) return res.status(502).json({ error: "The AI service returned an empty reply. Please try again." });
    return res.json({ reply });
  } catch (error) {
    console.error("Chat route failed:", error.message);
    return res.status(500).json({ error: "Something went wrong on the server. Please try again." });
  }
});

app.post("/api/fact-check", async (req, res) => {
  try {
    const claim = String(req.body?.claim || "").trim();
    if (!claim) return res.status(400).json({ error: "Please enter a claim or headline." });
    if (claim.length > 1000) return res.status(400).json({ error: "Please keep the claim under 1,000 characters." });

    if (!process.env.GOOGLE_FACT_CHECK_API_KEY) {
      return res.status(503).json({
        error: "Live fact-check search is not configured. Add GOOGLE_FACT_CHECK_API_KEY to hosting Secrets, or use the linked fact-check resources and treat this claim as unverified."
      });
    }

    const url = new URL("https://factchecktools.googleapis.com/v1alpha1/claims:search");
    url.searchParams.set("query", claim);
    url.searchParams.set("key", process.env.GOOGLE_FACT_CHECK_API_KEY);
    url.searchParams.set("pageSize", "5");

    const apiResponse = await fetch(url);
    const data = await apiResponse.json().catch(() => ({}));
    if (!apiResponse.ok) {
      console.error("Google Fact Check API error:", apiResponse.status);
      return res.status(502).json({ error: "The fact-check search service could not be reached. Check the Google API key and API setup." });
    }

    const matches = (data.claims || []).flatMap(item =>
      (item.claimReview || []).map(review => ({
        publisher: review.publisher?.name || "Fact-check publisher",
        text: review.title || item.text || "",
        rating: review.textualRating || "No rating listed",
        url: review.url || ""
      }))
    ).slice(0, 5);

    return res.json({ matches });
  } catch (error) {
    console.error("Fact-check route failed:", error.message);
    return res.status(500).json({ error: "Something went wrong while searching fact-check records." });
  }
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`Smart Media Awareness Hub server running on port ${PORT}`);
});
